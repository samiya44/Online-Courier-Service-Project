
package Samiya;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WelcomePage extends JFrame {

    public WelcomePage() {
        setTitle("Welcome to Online Courier Service");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel titleLabel = new JLabel("Welcome to Online Courier Service");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JButton enterButton = new JButton("Enter");
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openNodeSelectionPage();
            }
        });

        add(titleLabel);
        add(enterButton);

        setVisible(true);
    }

    private void openNodeSelectionPage() {
        setVisible(false);
        new NodeSelectionPage();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new WelcomePage();
            }
        });
    }
}

class NodeSelectionPage extends JFrame {

    public NodeSelectionPage() {
        setTitle("Node Selection");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel titleLabel = new JLabel("Select an option:");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JButton customerButton = new JButton("Customer Panel");
        customerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openCustomerPanel();
            }
        });

        JButton courierButton = new JButton("Courier Service");
        courierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openCourierService();
            }
        });

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBack();
            }
        });

        add(titleLabel);
        add(customerButton);
        add(courierButton);
        add(backButton);

        setVisible(true);
    }

    private void openCustomerPanel() {
        setVisible(false);
        new CustomerPanel();
    }

  private void openCourierService() {
    setVisible(false);
    ShortestPathGUI shortestPathGUI = new ShortestPathGUI();
    shortestPathGUI.setVisible(true);
}


    private void goBack() {
        setVisible(false);
        new WelcomePage();
    }
}

class CustomerPanel extends JFrame {

    public CustomerPanel() {
        setTitle("Customer Panel");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel titleLabel = new JLabel("Select a product:");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JButton foodButton = new JButton("Food");
        foodButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Food");
            }
        });

        JButton dressButton = new JButton("Dress");
        dressButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Dress");
            }
        });

        JButton tvButton = new JButton("TV");
        tvButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("TV");
            }
        });

        JButton fridgeButton = new JButton("Fridge");
        fridgeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Fridge");
            }
        });

        JButton sweetsButton = new JButton("Sweets");
        sweetsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Sweets");
            }
        });

        JButton bikeButton = new JButton("Bike");
        bikeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Bike");
            }
        });

        JButton carButton = new JButton("Car");
        carButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Car");
            }
        });

        JButton groceriesButton = new JButton("Groceries");
        groceriesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocationPanel("Groceries");
            }
        });

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBack();
            }
        });

        add(titleLabel);
        add(foodButton);
        add(dressButton);
        add(tvButton);
        add(fridgeButton);
        add(sweetsButton);
        add(bikeButton);
        add(carButton);
        add(groceriesButton);
        add(backButton);

        setVisible(true);
    }

    private void openLocationPanel(String product) {
        setVisible(false);
        new LocationPanel(product);
    }

    private void goBack() {
        setVisible(false);
        new NodeSelectionPage();
    }
}

class LocationPanel extends JFrame {

    private String product;
    private JComboBox<String> locationComboBox;

    public LocationPanel(String product) {
        this.product = product;

        setTitle("Location Panel");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel titleLabel = new JLabel("Set your location and provide phone number:");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Create the JComboBox and populate it with the list of locations
        locationComboBox = new JComboBox<>();
locationComboBox.addItem("Norshingdi");
locationComboBox.addItem("Madhobdi");
locationComboBox.addItem("Kandail");
locationComboBox.addItem("Pachruki");
locationComboBox.addItem("Sonpara");
locationComboBox.addItem("Banti");
locationComboBox.addItem("Shahughat");
locationComboBox.addItem("Gausia");
locationComboBox.addItem("UsBanglaMedical");
locationComboBox.addItem("Borpa");
locationComboBox.addItem("Rupsi");
locationComboBox.addItem("Borabo");
locationComboBox.addItem("Tarabo");
locationComboBox.addItem("Kachpur");
locationComboBox.addItem("ChittagongRoad");
locationComboBox.addItem("Mouchak");
locationComboBox.addItem("Shanarpar");
locationComboBox.addItem("Signboard");
locationComboBox.addItem("SaddamMarket");
locationComboBox.addItem("MatuailMedical");
locationComboBox.addItem("Raerbag");
locationComboBox.addItem("Shonirakra");
locationComboBox.addItem("Kajla");
locationComboBox.addItem("Jatrabari");
locationComboBox.addItem("Rajdhani");
locationComboBox.addItem("Saedabad");
locationComboBox.addItem("Gulistan");
locationComboBox.addItem("Dhanmondi");
locationComboBox.addItem("Rampura");
locationComboBox.addItem("Badda");
locationComboBox.addItem("Banani");
locationComboBox.addItem("Gulshan");
locationComboBox.addItem("Uttara");
locationComboBox.addItem("Mirpur");
locationComboBox.addItem("Kuril");
locationComboBox.addItem("Purbachal");
locationComboBox.addItem("Gub");
        // Add more locations as needed

        JTextField phoneField = new JTextField(20);

        JButton confirmButton = new JButton("Confirm Order");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmOrder();
            }
        });

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBack();
            }
        });

        add(titleLabel);
        add(new JLabel("Product: " + product));
        add(new JLabel("Location:"));
        add(locationComboBox);
        add(new JLabel("Phone Number:"));
        add(phoneField);
        add(confirmButton);
        add(backButton);

        setVisible(true);
    }

    private void confirmOrder() {
        String selectedLocation = (String) locationComboBox.getSelectedItem();
        // Code to confirm the order and display a confirmation message
        JOptionPane.showMessageDialog(this, "Parcel Booked for Location: " + selectedLocation);
    }

    private void goBack() {
        setVisible(false);
        new CustomerPanel();
    }
}





