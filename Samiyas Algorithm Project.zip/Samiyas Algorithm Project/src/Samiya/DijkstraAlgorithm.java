
package Samiya;
import java.util.*;

public class DijkstraAlgorithm {
    private Graph graph;

    public DijkstraAlgorithm(Graph graph) {
        this.graph = graph;
    }

    public List<Node> findShortestPath(Node startNode, Node destinationNode) {
        Map<Node, Integer> distances = new HashMap<>();
        Map<Node, Node> previousNodes = new HashMap<>();
        Set<Node> visited = new HashSet<>();

        PriorityQueue<Node> priorityQueue = new PriorityQueue<>(Comparator.comparingInt(distances::get));
        priorityQueue.add(startNode);
        distances.put(startNode, 0);

        while (!priorityQueue.isEmpty()) {
            Node currentNode = priorityQueue.poll();
            visited.add(currentNode);

            if (currentNode.equals(destinationNode)) {
                break;
            }

            List<Node> neighbors = graph.getAdjacentNodes(currentNode);
            for (Node neighbor : neighbors) {
                if (!visited.contains(neighbor)) {
                    int distance = distances.get(currentNode) + 1; // Assuming each edge has a weight of 1

                    if (!distances.containsKey(neighbor) || distance < distances.get(neighbor)) {
                        distances.put(neighbor, distance);
                        previousNodes.put(neighbor, currentNode);
                        priorityQueue.add(neighbor);
                    }
                }
            }
        }

        if (!previousNodes.containsKey(destinationNode)) {
            return new ArrayList<>();
        }

        List<Node> shortestPath = new ArrayList<>();
        Node currentNode = destinationNode;
        while (currentNode != null) {
            shortestPath.add(0, currentNode);
            currentNode = previousNodes.get(currentNode);
        }

        return shortestPath;
    }
}