
package Samiya;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ShortestPathGUI extends JFrame {
    private JComboBox<Node> startNodeComboBox;
    private JComboBox<Node> destinationNodeComboBox;
    private Graph graph;

    public ShortestPathGUI() {
        setTitle("Online Courier Service");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        graph = new Graph();
        Node customerLocation = new Node("Customer's Location", 0);
        Node courierServiceLocation = new Node("Courier Service Location", 1);
        // Add nodes to the graph
        Node norshingdi = new Node("Norshingdi", 0);
        Node madhobdi = new Node("Madhobdi", 1);
        Node kandail = new Node("Kandail", 2);
        Node pachruki = new Node("Pachruki", 3);
        Node sonpara = new Node("Sonpara", 4);
        Node banti = new Node("Banti", 5);
        Node shahughat = new Node("Shahughat", 6);
        Node gausia = new Node("Gausia", 7);
        Node usBanglaMedical = new Node("US BANGLA MEDICAL", 8);
        Node borpa = new Node("Borpa", 9);
        Node rupsi = new Node("Rupsi", 10);
        Node borabo = new Node("Borabo", 11);
        Node tarabo = new Node("Tarabo", 12);
        Node kachpur = new Node("Kachpur", 13);
        Node chittagongRoad = new Node("Chittagong road", 14);
        Node mouchak = new Node("Mouchak", 15);
        Node shanarpar = new Node("Shanarpar", 16);
        Node signboard = new Node("Sign Board", 17);
        Node saddamMarket = new Node("Saddam Market", 18);
        Node matuailMedical = new Node("Matuail Medical", 19);
        Node raerbag = new Node("Raerbag", 20);
        Node shonirakra = new Node("Shonirakra", 21);
        Node kajla = new Node("Kajla", 22);
        Node jatrabari = new Node("Jatrabari", 23);
        Node rajdhani = new Node("Rajdhani", 24);
        Node saedabad = new Node("Saedabad", 25);
        Node gulistan = new Node("Gulistan", 26);
        Node dhanmondi = new Node("Dhanmondi", 27);
        Node rampura = new Node("Rampura", 28);
        Node badda = new Node("Badda", 29);
        Node banani = new Node("Banani", 30);
        Node gulshan = new Node("Gulshan", 31);
        Node uttora = new Node("Uttora", 32);
        Node mirpur = new Node("Mirpur", 33);
        Node kuril = new Node("Kuril", 34);
        Node purbachal = new Node("Purbachal", 35);
        Node gub = new Node("GUB", 36);

        graph.addNode(customerLocation);
        graph.addNode(courierServiceLocation);
        
        graph.addNode(norshingdi);
        graph.addNode(madhobdi);
        graph.addNode(kandail);
        graph.addNode(pachruki);
        graph.addNode(sonpara);
        graph.addNode(banti);
        graph.addNode(shahughat);
        graph.addNode(gausia);
        graph.addNode(usBanglaMedical);
        graph.addNode(borpa);
        graph.addNode(rupsi);
        graph.addNode(borabo);
        graph.addNode(tarabo);
        graph.addNode(kachpur);
        graph.addNode(chittagongRoad);
        graph.addNode(mouchak);
        graph.addNode(shanarpar);
        graph.addNode(signboard);
        graph.addNode(saddamMarket);
        graph.addNode(matuailMedical);
        graph.addNode(raerbag);
        graph.addNode(shonirakra);
        graph.addNode(kajla);
        graph.addNode(jatrabari);
        graph.addNode(rajdhani);
        graph.addNode(saedabad);
        graph.addNode(gulistan);
        graph.addNode(dhanmondi);
        graph.addNode(rampura);
        graph.addNode(badda);
        graph.addNode(banani);
        graph.addNode(gulshan);
        graph.addNode(uttora);
        graph.addNode(mirpur);
        graph.addNode(kuril);
        graph.addNode(purbachal);
        graph.addNode(gub);

        // Add edges to the graph
        graph.addEdge(customerLocation, courierServiceLocation);
        graph.addEdge(norshingdi, madhobdi);
        graph.addEdge(madhobdi, kandail);
        graph.addEdge(kandail, pachruki);
        graph.addEdge(pachruki, sonpara);
        graph.addEdge(sonpara, banti);
        graph.addEdge(banti, shahughat);
        graph.addEdge(shahughat, gausia);
        graph.addEdge(gausia, usBanglaMedical);
        graph.addEdge(usBanglaMedical, borpa);
        graph.addEdge(borpa, rupsi);
        graph.addEdge(rupsi, borabo);
        graph.addEdge(borabo, tarabo);
        graph.addEdge(tarabo, kachpur);
        graph.addEdge(kachpur, chittagongRoad);
        graph.addEdge(chittagongRoad, mouchak);
        graph.addEdge(mouchak, shanarpar);
        graph.addEdge(shanarpar, signboard);
        graph.addEdge(signboard, saddamMarket);
        graph.addEdge(saddamMarket, matuailMedical);
        graph.addEdge(matuailMedical, raerbag);
        graph.addEdge(raerbag, shonirakra);
        graph.addEdge(shonirakra, kajla);
        graph.addEdge(kajla, jatrabari);
        graph.addEdge(jatrabari, rajdhani);
        graph.addEdge(rajdhani, saedabad);
        graph.addEdge(saedabad, gulistan);
        graph.addEdge(gulistan, dhanmondi);
        graph.addEdge(dhanmondi, rampura);
        graph.addEdge(rampura, badda);
        graph.addEdge(badda, banani);
        graph.addEdge(banani, gulshan);
        graph.addEdge(gulshan, uttora);
        graph.addEdge(uttora, mirpur);
        graph.addEdge(mirpur, kuril);
        graph.addEdge(kuril, purbachal);
        graph.addEdge(purbachal, gub);

       startNodeComboBox = new JComboBox<>();
        destinationNodeComboBox = new JComboBox<>();

        // Add nodes to the comboboxes
        Node[] nodes = {
                norshingdi, madhobdi, kandail, pachruki, sonpara, banti, shahughat, gausia, usBanglaMedical, borpa,
                rupsi, borabo, tarabo, kachpur, chittagongRoad, mouchak, shanarpar, signboard, saddamMarket,
                matuailMedical, raerbag, shonirakra, kajla, jatrabari, rajdhani, saedabad, gulistan, dhanmondi,
                rampura, badda, banani, gulshan, uttora, mirpur, kuril, purbachal, gub
        };
       startNodeComboBox.setModel(new DefaultComboBoxModel<>(nodes));
        destinationNodeComboBox.setModel(new DefaultComboBoxModel<>(nodes));

        JButton calculateButton = new JButton("Show The Easiest Way to deliver");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Node startNode = (Node) startNodeComboBox.getSelectedItem();
                Node destinationNode = (Node) destinationNodeComboBox.getSelectedItem();

                DijkstraAlgorithm dijkstraAlgorithm = new DijkstraAlgorithm(graph);
                List<Node> shortestPath = dijkstraAlgorithm.findShortestPath(startNode, destinationNode);

                StringBuilder path = new StringBuilder();
                for (Node node : shortestPath) {
                    path.append(node.getName()).append(" -> ");
                }
                path.setLength(path.length() - 4); // Remove the last arrow and space

                JOptionPane.showMessageDialog(ShortestPathGUI.this, "Shortest Path: " + path.toString());
            }
        });

        add(startNodeComboBox);
        add(destinationNodeComboBox);
        add(calculateButton);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ShortestPathGUI();
            }
        });
    }
}